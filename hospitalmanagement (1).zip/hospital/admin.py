from django.contrib import admin
from .models import Doctor,Patient,Appointment,PatientDischargeDetails,Bed,Nurse,Farmacy
# Register your models here.
class DoctorAdmin(admin.ModelAdmin):
    pass
admin.site.register(Doctor, DoctorAdmin)

class PatientAdmin(admin.ModelAdmin):
    pass
admin.site.register(Patient, PatientAdmin)

class AppointmentAdmin(admin.ModelAdmin):
    pass
admin.site.register(Appointment, AppointmentAdmin)

class PatientDischargeDetailsAdmin(admin.ModelAdmin):
    pass
admin.site.register(PatientDischargeDetails, PatientDischargeDetailsAdmin)
#admin.site.register(Bed, Admin)
#admin.site.register(Farmacy, Admin)
#admin.site.register(Nurse, Admin)

